export enum CloneRepositoryTab {
  DotCom = 0,
  Enterprise,
  Generic,
}
